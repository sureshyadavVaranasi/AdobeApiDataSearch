import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  template: '<app-adobepage></app-adobepage>',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'apiproject';
  

}
