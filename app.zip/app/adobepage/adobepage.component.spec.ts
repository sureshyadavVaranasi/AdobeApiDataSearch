import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdobepageComponent } from './adobepage.component';

describe('AdobepageComponent', () => {
  let component: AdobepageComponent;
  let fixture: ComponentFixture<AdobepageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdobepageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdobepageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
