import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
//import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';




@Injectable({
  providedIn: 'root'
})
export class AdobeservicesService {

  url = "https://aravindtwitter.herokuapp.com/twittersearch?key=adobe";

  constructor (private _http:HttpClient){}
  /*getData(){
    return this._http.get(this.url);
  }*/
  getData():Observable<any>{
    return this._http.get<any[]>(this.url);
   
}

}
