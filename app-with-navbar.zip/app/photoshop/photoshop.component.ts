import { Component, OnInit } from '@angular/core';
import { AdobeservicesService } from '../adobeservices.service';


@Component({
  selector: 'app-photoshop',
  templateUrl: './photoshop.component.html',
  styleUrls: ['./photoshop.component.css']
})
export class PhotoshopComponent implements OnInit {

  statuses:any = [];
  constructor(private twiterPhotoshopData: AdobeservicesService) { }

  ngOnInit(): void {
    this.twiterPhotoshopData.getPhotoshopData().subscribe((data) => {
      this.statuses = data.statuses;
      console.log(data);
    });

  }

  searchText: string = '';

    onSearchTextEntered(searchValue:string){
      this.searchText = searchValue;
      console.log(this.searchText);
    }

}
