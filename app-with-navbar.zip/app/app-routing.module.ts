import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdobepageComponent } from './adobepage/adobepage.component';
import { PhotoshopComponent } from './photoshop/photoshop.component';

const routes: Routes = [
  //{ path: '',   redirectTo: '', pathMatch: 'full' },
  { path: '', component: AdobepageComponent },
  { path: 'photoshop', component: PhotoshopComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
