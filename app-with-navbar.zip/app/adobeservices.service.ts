import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
//import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';




@Injectable({
  providedIn: 'root'
})
export class AdobeservicesService {

  url = "https://aravindtwitter.herokuapp.com/twittersearch?key=adobe";
  url2 = "https://aravindtwitter.herokuapp.com/twittersearch?key=photoshop";

  constructor (private _http:HttpClient){}
  /*getData(){
    return this._http.get(this.url);
  }*/
  getData():Observable<any>{
    return this._http.get<any[]>(this.url);
  }


  getPhotoshopData():Observable<any>{
    return this._http.get<any[]>(this.url2);
  }

}
