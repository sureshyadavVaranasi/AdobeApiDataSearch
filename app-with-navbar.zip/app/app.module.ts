import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AdobepageComponent } from './adobepage/adobepage.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { SearchComponent } from './search/search.component';
import { PhotoshopComponent } from './photoshop/photoshop.component';
import { AdobeheaderComponent } from './adobeheader/adobeheader.component';

@NgModule({
  declarations: [
    AppComponent,
    AdobepageComponent,
    SearchComponent,
    PhotoshopComponent,
    AdobeheaderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,HttpClientModule,FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
