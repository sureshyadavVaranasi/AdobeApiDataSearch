import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  template: '<app-adobeheader></app-adobeheader>',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'apiproject';
  

}
