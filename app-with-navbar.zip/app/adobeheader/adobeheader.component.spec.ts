import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdobeheaderComponent } from './adobeheader.component';

describe('AdobeheaderComponent', () => {
  let component: AdobeheaderComponent;
  let fixture: ComponentFixture<AdobeheaderComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdobeheaderComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdobeheaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
