import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-adobeheader',
  templateUrl: './adobeheader.component.html',
  styleUrls: ['./adobeheader.component.css']
})
export class AdobeheaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
