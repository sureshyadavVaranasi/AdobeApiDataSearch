import { Component, OnInit } from '@angular/core';
import { AdobeservicesService } from '../adobeservices.service';

@Component({
  selector: 'app-adobepage',
  templateUrl: './adobepage.component.html',
  styleUrls: ['./adobepage.component.css']
})
export class AdobepageComponent implements OnInit {
  
  statuses:any = [];
  constructor(private twiterData: AdobeservicesService) { }

  ngOnInit(): void {
    this.twiterData.getData().subscribe((data) => {
      this.statuses = data.statuses;
      console.log(data);
    });

    
  }
    searchText: string = '';

    onSearchTextEntered(searchValue:string){
      this.searchText = searchValue;
      console.log(this.searchText);
    }

}
